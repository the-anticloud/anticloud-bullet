# 10 Technical Handoff

**Project:** BULLET
**Upstream:** https://github.com/JBGruber/bullet

Content specific to BULLET in category ARTILLERY_MANUFACTURING.
