# 23 How To Cite

**Project:** BULLET
**Upstream:** https://github.com/JBGruber/bullet

Content specific to BULLET in category ARTILLERY_MANUFACTURING.
