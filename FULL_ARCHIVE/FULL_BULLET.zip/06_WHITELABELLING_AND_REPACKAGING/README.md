# 06 Whitelabelling And Repackaging

**Project:** BULLET
**Upstream:** https://github.com/JBGruber/bullet

Content specific to BULLET in category ARTILLERY_MANUFACTURING.
